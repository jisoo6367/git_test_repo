package sample.less01;

public class ChefTest {

}
